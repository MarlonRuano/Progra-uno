﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entrada_salida
{
    internal class Program
    {
        
        
         public static void Main(string[] args)
         {
            {
                string nombre;

                Console.WriteLine("Escribe tu nombre porfavor :D ");
                nombre = Console.ReadLine();
                Console.WriteLine("Bienvenido  " + nombre);
                Console.ReadLine();
            }
        }
    }
}
